import Vue from 'vue'
import Router from 'vue-router'
import Msite from '@/pages/home/Msite'
import Discover from '@/pages/discover/Discover'
import Order from '@/pages/order/Order'
import Profile from '@/pages/profile/Profile'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      redirect:"/home"
    },
    {
    	path:"/home",
    	component:Msite
    },
    {
    	path:"/order",
    	component:Order
    },
    {
    	path:"/discover",
    	component:Discover
    },
    {
    	path:"/profile",
    	component:Profile
    }
  ]
})

<template>
	
	<div>
		
		<header>
			<div class="location">
				<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 26 31" class="icon-location">
					<path fill="#FFF" fill-rule="evenodd" d="M22.116 22.601c-2.329 2.804-7.669 7.827-7.669 7.827-.799.762-2.094.763-2.897-.008 0 0-5.26-4.97-7.643-7.796C1.524 19.8 0 16.89 0 13.194 0 5.908 5.82 0 13 0s13 5.907 13 13.195c0 3.682-1.554 6.602-3.884 9.406zM18 13a5 5 0 1 0-10 0 5 5 0 0 0 10 0z">
					</path>
				</svg>
				<span>金银路河北软件职业技术学院东校区</span>
				<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 14 8" class="icon-arrow">
					<path fill="#FFF" fill-rule="evenodd" d="M5.588 6.588c.78.78 2.04.784 2.824 0l5.176-5.176c.78-.78.517-1.412-.582-1.412H.994C-.107 0-.372.628.412 1.412l5.176 5.176z">
					</path>
				</svg>
			</div>
		</header>
		<div class="search">
				<div class="button">
					<a class="content">
						<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16">
							<path fill-opacity=".38" d="M14.778 13.732a.739.739 0 1 1-1.056 1.036l-2.515-2.565a.864.864 0 0 1-.01-1.206 4.894 4.894 0 0 0 1.357-3.651c-.126-2.492-2.156-4.52-4.648-4.647a4.911 4.911 0 0 0-5.16 5.163c.126 2.475 2.13 4.496 4.605 4.642.451.026.896-.008 1.326-.1a.739.739 0 0 1 .308 1.446c-.56.12-1.137.164-1.72.13-3.227-.19-5.83-2.815-5.995-6.042a6.39 6.39 0 0 1 6.71-6.715c3.25.165 5.884 2.8 6.05 6.048a6.37 6.37 0 0 1-1.374 4.3l2.12 2.161z">
							</path>
						</svg>
						<span>搜索饿了么商家、商品名称</span>
					</a>
				</div>
		</div>
		<!-- 热门搜索 -->
		<section class="hot-search">
			<ul>
				<li v-for="(item,index) in hotsearches" :key="index">{{item.word}}</li>
			</ul>
		</section>

		<!-- 食品分类轮播图 -->
		<section class="entries">
			<svg v-if="entries.length==0" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1080 490">
					<defs>
						<path id="b" d="M0 0h1080v489H0z"/>
						<filter id="a" width="200%" height="200%" x="-50%" y="-50%" filterUnits="objectBoundingBox">
						<feOffset dy="1" in="SourceAlpha" result="shadowOffsetOuter1"/>
						<feColorMatrix in="shadowOffsetOuter1" values="0 0 0 0 0.933333333 0 0 0 0 0.933333333 0 0 0 0 0.933333333 0 0 0 1 0"/>
						</filter>
					</defs>
					<g fill="none" fill-rule="evenodd">
						<g>
						<use fill="#000" filter="url(#a)" xlink:href="#b"/>
						<use fill="#FFF" xlink:href="#b"/>
						</g>
						<g fill="#F6F6F6">
						<g transform="translate(76 36)">
							<path d="M9 139h100v34H9z"/>
							<ellipse cx="59" cy="59" rx="59" ry="59"/></g>
							<g transform="translate(346 36)">
							<path d="M9 139h100v34H9z"/><ellipse cx="59" cy="59" rx="59" ry="59"/>
							</g>
							<g transform="translate(616 36)">
							<path d="M9 139h100v34H9z"/>
							<ellipse cx="59" cy="59" rx="59" ry="59"/>
							</g>
							<g transform="translate(886 36)">
								<path d="M9 139h100v34H9z"/>
								<ellipse cx="59" cy="59" rx="59" ry="59"/>
							</g>
							</g>
							<g fill="#F6F6F6">
							<g transform="translate(76 252)">
								<path d="M9 139h100v34H9z"/>
								<ellipse cx="59" cy="59" rx="59" ry="59"/></g><g transform="translate(346 252)"><path d="M9 139h100v34H9z"/><ellipse cx="59" cy="59" rx="59" ry="59"/></g><g transform="translate(616 252)"><path d="M9 139h100v34H9z"/><ellipse cx="59" cy="59" rx="59" ry="59"/></g><g transform="translate(886 252)"><path d="M9 139h100v34H9z"/><ellipse cx="59" cy="59" rx="59" ry="59"/>
								</g>
							</g>
							</g>
			</svg>
			<mt-swipe :auto="4000">
				<mt-swipe-item v-for="(item,index) in entries" :key="index">
					<a href="" v-for="(item2,index2) in item" :key="index2">
						<img :src="item2.image_hash | imgUrl" alt="">
						<span>{{item2.name}}</span>
					</a>
				</mt-swipe-item>
			</mt-swipe>

		</section>

		<!-- 推荐商家 -->
		<section class="recommends">
			<!-- 标题 -->
			<section class="shop-title">
				<h3>推荐商家</h3>
			</section>

			<!-- 商家列表 -->
			<section class="shop-list" v-for="(item,index) in restaurants" :key="index">
				<div class="shop-info">
						<div class="shop-logo">
							<img :src="item.restaurant.image_path|imgUrl">
						</div>
						<div class="shop-main">
							<div class="title">
								<h3>{{item.restaurant.name}}</h3>
								
							</div>
							<div class="rating">
								<div class="ratingWrap">
									<elm-star :score="item.restaurant.rating" :size="24"></elm-star>
									<span>{{item.restaurant.rating}}</span>
									<span>{{item.restaurant.recent_order_num}}单</span>
								</div>
								<div class="deliver-mode">
									<span>蜂鸟快送</span>
								</div>
							</div>
							<div class="fee">
								<div class="money">
									<span>¥{{item.restaurant.float_minimum_order_amount}}起送</span>
									<span>优惠配送费¥{{item.restaurant.delivery_fee_discount}}</span>
								</div>
								<div class="distance">
									<span>{{item.restaurant.distance / 1000|toFix}} km</span>
									<span>{{item.restaurant.order_lead_time}}分钟</span>
								</div>
							</div>
						</div>
				</div>
			
				<div class="shop-activity">             
					<div class="activities">
						<div class="activityList" v-for="(item,index) in item.restaurant.activities" :key="index">
							<span style="background-color: rgb(240, 115, 115);color:#fff">{{item.icon_name}}</span>
							<span>{{item.tips}}</span>
						</div>
						               
					</div>
					<div class="activityBtn">
							<span>{{item.restaurant.activities.length}}个活动</span>
							<img src=" ">
						</div>
				</div>
			</section>
			

		</section>

		<elm-tabbar></elm-tabbar>
	</div>
</template>

<script>
	import Tabbar from "@/components/footer/Tabbar"
	import {getHotSearches,getEntries, getRestaurants} from "@/api/msite"
	import _ from "lodash"

	import Vue from "vue"
	import { Swipe, SwipeItem } from 'mint-ui';

	import "mint-ui/lib/style.css"
	import "mint-ui/lib/index.js"

	Vue.component(Swipe.name, Swipe);
	Vue.component(SwipeItem.name, SwipeItem);

	import Star from "@/components/star/Star"
	export default {
		components:{
			"elm-tabbar":Tabbar,
			"elm-star":Star
		},
		data(){
			return {
				hotsearches:[],
				entries:[],
				restaurants:[]
			}
		},
		//过滤器
		filters:{
			imgUrl(src){
				// src = 7d8a867c870b22bc74c87c348b75528djpeg
				//src =  3bfbf5596e87a1d6647cd4d3ac9f6efepng
								
				let url = "https://fuss10.elemecdn.com/";
				
				//1. 造筛子(正则表达式)
				let reg = /jpeg|jpg|png|gif$/;

				//2. 筛沙子
				let res = src.match(reg);
				console.log(res[0]);

				url += src.slice(0,1)+"/"+src.slice(1,3)+"/"+src.slice(3)+"."+res[0];
				url += "?imageMogr/format/webp/thumbnail/!90x90r/gravity/Center/crop/90x90/";
				return url;
			},
			//保留2位小数
			toFix(data){
				return data.toFixed(2);
			}
		},
		created(){
			//获取热门搜索数据
			getHotSearches()
			.then((data) => {
				//console.log(data.data)
				this.hotsearches = data.data;
			})
			.catch((err) => {
				console.log(err);
			})

			//获取分类轮播图数据
			getEntries()
			.then((data) => {
				//console.log(data.data[0].entries)
				this.entries = _.chunk(data.data[0].entries, 8);
				//console.log(this.entries)
			})
			.catch((err) => {
				console.log(err);
			})

			//获取推荐的商家列表
			getRestaurants()
			.then((res) => {
				console.log(res.data.items);
				this.restaurants = res.data.items;
			})
			.catch((err) => {
				console.log(err)
			})
		}
	}

	
</script>

<style lang="less" scoped>
	*{box-sizing: border-box}
	header{
		height: 1.333333rem;
		background-image: linear-gradient(90deg,#0af,#0085ff);
		display:flex;
		align-items:center;
		padding-left:0.346667rem;
		
		.location{
			display:flex;
			align-items:center;
			.icon-location{
				width:0.4rem;
				height:0.426667rem;
			}
			.icon-arrow{
				width:0.186667rem;
				height:0.106667rem;
			}
			span{
				font-size:0.453333rem;
				margin: 0 1.333333vw;
			    max-width: 80%;
			    white-space: nowrap;
			    overflow: hidden;
			    text-overflow: ellipsis;
			    color:#fff;
			}
		}
		
	}
	.search{

			width:100%;
		    display:flex;
		    align-items:center;
			justify-content:center;
			background-image: linear-gradient(90deg,#0af,#0085ff);
			padding: 0.5rem 0.346667rem 0.346667rem;
			position: sticky;
			top: 0;
			z-index: 1000;

		    .button{
		    	width:100%;
		    	height:0.986667rem;
		    	line-height:0.986667rem;
		    	background:#fff;

		    	a{
		    		display:flex;
		    		align-items:center;
		    		justify-content:center;
		    		text-decoration:none;

		    		svg{

		    			width: 0.386667rem;
		    			height: 0.386667rem;
		    		}
		    		span{
		    			font-size:0.373333rem;
		    			color:#999;
		    			margin-left:0.16rem
		    		}
		    	}
		    }
		}

	.hot-search{
		width: 100%;
		height: 1.12rem;
		background-image: linear-gradient(90deg,#0af,#0085ff);
		padding: 0 0.346667rem;

		ul{
			width: 100%;
			overflow-x: auto;    /*水平方向超出的内容不隐藏*/
			white-space: nowrap; /*超出部分不换行*/
			&::-webkit-scrollbar{
				display: none
			}
			li{
				font-size: 0.32rem;
				display: inline-block;
				color: #fff;
				&:not(:last-child){
					margin-right: 0.48rem;
				}
			}
		}
	}
	// 食品分类轮播图
	.entries{
		height: 4.533333rem;
		a{
			display: flex;
			flex-direction: column;
			align-items: center;
			width: 25%;
			float: left;
			text-decoration: none;
			margin-top: 0.373333rem;
			img{
				width: 0.853333rem;
				height: 0.85333rem;
			}
			span{
				font-size: 0.32rem;
				color: #666;
				margin-top: 0.266667rem;
			}
		}
	}

	// 推荐商家
	.shop-title{
		h3{
			font-size: .4rem;
			height: 1.2rem;
			display: flex;
			justify-content: center;
			align-items: center;
			&:before,&:after{
				content: "";
				display: block;
				width: .533333rem;
				height: .026667rem;
				background-color: #999;
			}
			&:before{
				margin-right: .346667rem;
			}
			&:after{
				margin-left: .346667rem;
			}
		}
	}
	.shop-list{
    position: relative;
    padding: .4rem 0;
    .shop-info{
        display: flex;
        justify-content: flex-start;
        align-items: stretch;
        padding: 0 0.266667rem;
        .shop-logo{
            width: 1.733333rem;
            height: 1.733333rem;
            img{
                width: 100%;
                height: 100%;
            }
        }

        .shop-main{
            display: flex;
            justify-content: space-between;
            flex-direction: column;
            padding-left: 0.266667rem;
            flex-grow: 1;
            div{
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            .title{
                h3{
                    font-size: 0.4rem;
                    color:#333;
                    font-weight: 700;
                }
                ul{
                    display: flex;
                    align-items: center;
                    li{
                        font-size: 0.266667rem;
                    }
                }
            }
            .rating{                
                span{
                    font-size: 0.293333rem;
                }
                .ratingWrap{
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                }
                .deliver-mode{
                    background-image: linear-gradient(90deg,#0af,#0085ff);
                    color:#fff;
                    font-size: 0.266667rem;
                    padding: 0.026667rem;
                }
            }
            .fee{                   
                span{
                    font-size: 0.293333rem;
                }
            }
        }        
    }
    
    .shop-activity{
        display:flex;
        justify-content: space-between;
        padding-left: 2.266667rem;        
        .activities{
            display: flex;
            flex-direction: column;
            white-space:nowrap;
            overflow:hidden;
            text-overflow:ellipse;
            span{
                font-size: 0.293333rem;                 
            }
            .activityList{
                margin-top: -0.266667rem;                   
            }               
        }
        .activityBtn{
                margin-top: -0.266667rem;
                text-align: right;
                span{
                    font-size: 0.24rem;
                }
            }        
    }    
}

		
		
		


</style>
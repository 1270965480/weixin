<template>
	
	<div>
		<h3>订单</h3>
		<elm-tabbar></elm-tabbar>
	</div>
</template>

<script>

	import Tabbar from "@/components/footer/Tabbar"
	export default {
		components:{
			"elm-tabbar":Tabbar
		}
	}
</script>

<style lang="less" scoped>
	
	
</style>
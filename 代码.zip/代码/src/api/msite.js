/**
 * 获取首页数据
 */
import axios from 'axios'

export function getHotSearches(){

    let url = "static/hot-search.json";

    return new Promise((success,error) => {
        axios.get(url)
        .then((res) => {
            success(res);
        })
        .catch((err) => {
            error(err);
        })
    });
    
}

//获取分类数据

export function getEntries(){

    let url = "static/entries.json";

    return new Promise((success,error) => {
        axios.get(url)
        .then((res) => {
            success(res);
        })
        .catch((err) => {
            error(err);
        })
    });
    
}


//获取推荐的商家列表
export function getRestaurants(){

    let url = "static/restaurants.json";

    return new Promise((success,error) => {
        axios.get(url)
        .then((res) => {
            success(res);
        })
        .catch((err) => {
            error(err);
        })
    });
    
}

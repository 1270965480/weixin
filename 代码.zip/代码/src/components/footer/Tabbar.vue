<template>

	<footer>
		<div>
			<a @click="redirect('/home')">
				<svg class="index-footerTabIcon_1EbB8wS"><use xlink:href="#h5-component-index"></use></svg>
				<span>首页</span>
			</a>
			<a @click="redirect('/discover')">
				<svg class="index-footerTabIcon_1EbB8wS"><use xlink:href="#h5-component-discoverRegular"></use></svg>
				<span>发现</span>
			</a>
			<a @click="redirect('/order')">
				<svg class="index-footerTabIcon_1EbB8wS"><use xlink:href="#h5-component-orderRegular"></use></svg>
				<span>订单</span>
			</a>
			<a @click="redirect('/profile')">
				<svg class="index-footerTabIcon_1EbB8wS"><use xlink:href="#h5-component-profileRegular"></use></svg>
				<span>我的</span>
			</a>
		</div>
	</footer>

</template>

<script>

	export default {

		methods:{
			redirect(router){
				this.$router.push({path: router})
			}
		}
	}
</script>

<style lang="less" scoped>

	footer{

    	div{
			background-color: #ffffff;
    		position: fixed;
		    bottom: 0;
		    z-index: 9999;
			height:1.6rem;
			width:100%;
	    	box-shadow: 0 -0.266667vw 0.533333vw rgba(0,0,0,.1);
    		display: flex;
	    	justify-content: space-around;
	    	
    		svg{
    			width: .533333rem;
    			height: .533333rem;
    		}
    		span{
    			display: block;
    			font-size: .266667rem;
    		}
    	}
	}
</style>
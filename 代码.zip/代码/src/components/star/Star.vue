<template>
    <div class="star" :class="startType">
        <span class="star-item" :class="item" v-for="(item,index) in starClasses" :key="index"></span>
    </div>
</template>

<script>
const CLS_ON = "on"
const CLS_OFF = "off"
const CLS_HALF = "half"
const LENGTH = 5;

export default {
    //接收父组件传递过来的参数：分值、尺寸
    props:{
        score:Number,
        size:Number
    },
    //根据分值计算显示几颗星星，例如：4.5 4.6 4.7就显示4课全亮，1颗半亮的
    computed:{
        startType(){
            return "star-"+this.size;
        },
        starClasses(){
            let score = Math.floor(this.score * 2) / 2; 
            // 3.3     3
            // 3.2     3
            // 35      3.5
            // 3.7     3.5
            let integer = Math.floor(score);  //确定全亮星星个数

            let hasDecimal = score % 1 != 0;  //有小数， 半亮星星的个数

            let result = [];
            for(let i=0;i<integer;i++){
                result.push(CLS_ON); //["on","on","on"]
            }

            if(hasDecimal){
                result.push(CLS_HALF); //["on","on","on","half"]
            }
            //剩下的放不亮的星星
            while(result.length < LENGTH){
                result.push(CLS_OFF);  //["on","on","on","half","off"]
            }
            return result;
        }
    }
}
</script>

<style lang="less" scoped>
    .star{
        &.star-24{
            .star-item{
                display: inline-block;
                width: 10px;
                height: 10px;
                background-size: 10px 10px;
                margin-right: 3px;
                
                &:last-child{
                    margin-right: 0;
                }
                // & 表示和.star-item是并且的关系，没有&表示父子关系
                &.on{
                    background-image:url('star24_on@2x.png')
                }
                &.half{
                    background-image:url('star24_half@2x.png')
                }
                &.off{
                    background-image:url('star24_off@2x.png')
                }
            }
            

        }
        &.star-36{

        }
        &.star-48{

        }
    }
</style>

<template>
    <div class="star" :class="starType">
        <span class="star-item" :class="item" v-for="(item,index) in starClasses" :key="index"></span>
    </div>
</template>

<script>
const CLS_ON = "on"
const CLS_OFF = "off"
const CLS_HALF = "half"
const LENGTH = 5;

export default {
    props:{
        score:Number,
        size:Number
    },
    computed:{
        starType(){
            return "star-"+this.size;
        },
        starClasses(){
            let score = Math.floor(this.score * 2)/2;
            let integer = Math.floor(score);
            let hasDecimal = score % 1 !== 0;
            let result = [];
            for(let i=0;i<integer;i++){
                result.push(CLS_ON);
            }
            if(hasDecimal){
                result.push(CLS_HALF)
            }
            while(result.length < LENGTH){
                result.push(CLS_OFF)
            }
            return result; 
        }
    }
}
</script>

<style lang="less" scoped>
    .star{
        font-size:0;
        .star-item{
            display:inline-block;
            background-repeat: no-repeat;       
        }
        &.star-24{
            .star-item{
                width: 10px;
                height: 10px;
                margin-right: 3px;
                background-size: 10px 10px;
                &:last-child{
                    margin-right: 0;
                }
                &.on{
                    background-image:url('star24_on@2x.png')
                }
                &.half{
                    background-image:url('star24_half@2x.png')
                }
                &.off{
                    background-image:url('star24_off@2x.png')
                }
            }           
        }
        &.star-36{
            .star-item{
                width: 15px;
                height: 15px;
                margin-right: 6px;
                background-size: 15px 15px;
                &:last-child{
                    margin-right: 0;
                }
                &.on{
                    background-image:url('star36_on@2x.png')
                }
                &.half{
                    background-image:url('star36_half@2x.png')
                }
                &.off{
                    background-image:url('star36_off@2x.png')
                }
            }
        }
        &.star-48{
            .star-item{
                width: 20px;
                height: 20px;
                margin-right: 9px;
                background-size: 20px 20px;
                &:last-child{
                    margin-right: 0;
                }
                background-size: 20px 20px;
                &.on{
                    background-image:url('star48_on@2x.png')
                }
                &.half{
                    background-image:url('star48_half@2x.png')
                }
                &.off{
                    background-image:url('star48_off@2x.png')
                }
            }
        }
    }
</style>
